# event-management-system
Project for the course Fullstack Application Development with Node.js + Express.js + React.js
