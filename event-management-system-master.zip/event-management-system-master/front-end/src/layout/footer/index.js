import React from 'react'
import './styles.css'

function Footer() {
  return (
    <footer className="body-text">
      Event Management System - Project for course Node Express React 2020
    </footer>
  )
}

export default Footer
