import { makeStyles } from '@material-ui/core/styles'

const useStyles = makeStyles({
  navLink: {
    color: '#fff',
  },
  right: {
    marginLeft: 'auto',
  },
})

export { useStyles }
