import React from 'react'

export default function MaximizedMeetingBox(props) {
  console.log(props)
  return (
    <React.Fragment>
      <p>{'FixedWrapper.Maximized'}</p>
      <p>
        This is sample FixedWrapper component. It shows widget placed as fixed
        on your website. It has two stated - maximized and minimized.
      </p>
    </React.Fragment>
  )
}
