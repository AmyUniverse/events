## Event Management System Project Front-End

### Installation

    npm install
    
Then copy .env.example into .env and set it's content with your environment configuration